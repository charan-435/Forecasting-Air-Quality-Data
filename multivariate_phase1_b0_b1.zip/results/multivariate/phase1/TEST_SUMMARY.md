# Phase 1 test execution summary

Run: 2026-11-02 17:29:49 UTC. R 4.3.3, lightgbm 4.7.0, parquet reader: nanoparquet 0.5.2.
Result: **22 / 22 passed**. Quality mask: none (UNMASKED).

| ID | Required item | Test | Result | Detail |
|---|---|---|---|---|
| T01 | 1 | Timestamp alignment across all six pollutants | PASS | 8880 identical instants for PM2.5,PM10,NO2,SO2,O3,CO |
| T02 | 2 | No duplicate timestamps | PASS | 0 duplicates in the panel and in each pollutant |
| T03 | data | 8,880 hours, no missing values, chronological, units | PASS | n=8880, 0 NA, hourly ascending; CO median 0.2330 mg/m3 |
| T04 | 3 | Feature counts: 24 (B0) and 144 (B1) | PASS | B0=24, B1=144 for every horizon and block |
| T05 | 4 | Deterministic feature-column ordering | PASS | first PM2.5__lag00, last CO__lag23 |
| T06 | features | X values equal the store value at origin minus lag | PASS | checked by timestamp lookup on sampled cells, all designs, horizons and blocks |
| T07 | 5 | Perturbing observations after origin t leaves X(t) unchanged | PASS | 69 origins incl. block edges; future, other-pollutant and t-24 perturbations had no effect |
| T08 | targets | y(t,h) = PM2.5(t+h) and target - origin = h hours | PASS | all designs, horizons and blocks |
| T09 | 6 | Every training target stays in the training block | PASS | h24:3066 h168:2922 h336:2754 h744:2346 |
| T10 | 7 | Every validation target stays in the validation block | PASS | h24:1464 h168:1320 h336:1152 h744:744 |
| T11 | 8 | Every test target stays in the test block | PASS | h24:2208 h168:2064 h336:1896 h744:1488 |
| T12 | 9 | All samples retained under the unmasked policy (incl. constant-fill) | PASS | train: 600 fill targets kept; validation: 336 fill targets kept; test: 936 fill targets kept |
| T13 | 10 | No quality-mask exclusion or origin threshold is applied | PASS | config enforced; no mask identifiers in pipeline code; full-fill origin 2023-06-15 00:00 kept |
| T14 | 11 | Sample counts match the independent calendar computation | PASS | h168 tes=2064 h168 tra=2922 h168 val=1320 h24 tes=2208 h24 tra=3066 h24 val=1464 h336 tes=1896 h336 tra=2754 h336 val=1152 h744 tes=1488 h744 tra=2346 h744 val=744 |
| T15 | 12 | No test labels are used in fitting or validation-based selection | PASS | best_iter=49 unchanged; predictions identical with perturbed or NA test labels |
| T16 | repro | Reproducibility with a fixed seed | PASS | identical predictions and dataset hashes across two runs (seed 2026) |
| T17 | leak | Legacy two-sided MRA and full-series imputation are not loaded | PASS | none of the legacy helpers exist after loading the layer; no legacy source() calls |
| T18 | metrics | MASE scale matches R/08_metrics.R and a brute-force loop | PASS | scale 4.112400 from 3089 pairs (2022-09-24 07:00 to 2023-01-31 23:00) |
| T19 | transform | Train-fitted transform contract (fit sees fitting rows only) | PASS | standardize/identity fitted on train only; reused unchanged on later blocks |
| T20 | family | Unregistered or missing families fail instead of falling back | PASS | catboost/xgboost not registered -> error; missing package -> error |
| T21 | metrics | Block bootstrap is seeded and brackets the point estimate | PASS | deterministic; CI contains point estimates; resamples keep n |
| T22 | repro | Recorded iteration counts are not overwritten by later fits | PASS | first fit keeps iterations_run=69, best_iter=39 after a 7-round fit |
